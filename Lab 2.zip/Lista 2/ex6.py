a = 10 
b = a
c = 9
d = c
c = c + 1

print(f"a = {a}\nb = {b}\nc = {c}\nd = {d}") #apresenta o valor de cada incógnita na tela