X = int(input('Digite um número: ')) #pedir o número X e Y 
Y = int(input('Digite outro número: '))

if (X > Y): #Indicar qual deles é maior 
    print(f"O número {X} é maior que o número {Y}") 
else:
    print(f"O número {Y} é maior que o número {X}")
    